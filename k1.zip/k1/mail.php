<?php
$s="kandlikarprajwala@gmail.com";
mail($s,'Sample Mail','Sample Content','From: onlinecharity2020@gmail.com');
?>