
<?php
	$conn=mysqli_connect("localhost","root","","charity2") or die("could not find conn");
	$db=mysqli_select_db($conn,"charity2") or die("could not find db");
	if(isSet($_REQUEST["register"]))
	{
		$name=$_REQUEST["name"];
		$email=$_REQUEST["email"];
		$pwd=$_REQUEST["pwd"];
		$city=$_REQUEST["city"];
		$state=$_REQUEST["state"];
		$contact=$_REQUEST["contact"];
		$q="select * from donor_user where d_email='$email';";
		$val=mysqli_query($conn,$q);
		$n=mysqli_num_rows($val);
		if($n==0)
		{
			$q="INSERT INTO donor_user (d_name, d_email, d_city, d_state, d_phone_no, pwd) VALUES ('$name', '$email', '$city', '$state', '$contact','$pwd');";
			mysqli_query($conn,$q);
			session_start();
			$_SESSION['reg']="true";
			if(isSet($_SESSION['reg']))
				header('Location: donor-login.php');
		}
		else
		{
			session_start();
			$_SESSION['user_exists']="true";
			if(isSet($_SESSION['user_exists']))
				header('Location: donor-login.php');
		}
	}
	
	if(isSet($_REQUEST["login"]))
	{
		$email=$_REQUEST["email"];
		$pwd=$_REQUEST["pwd"];
		$q="select * from donor_user where d_email='$email';";
		$val=mysqli_query($conn,$q);
		$n=mysqli_num_rows($val);
		if($n==1)
		{
			$row=mysqli_fetch_array($val,MYSQLI_BOTH);
			if($pwd == $row['pwd'])
			{
				setcookie("email","$email");
				header('Location: donor.php');
			}
			else
			{
				//session_start();
				$_SESSION['pass']="true";
				if(isSet($_SESSION['pass']))
					header('Location: donor-login.php');
			}
		}
		else
		{
			//session_start();
			$_SESSION['no_user']="true";
			if(isSet($_SESSION['no_user']))
				header('Location: donor-login.php');
		}
		
	}
?>