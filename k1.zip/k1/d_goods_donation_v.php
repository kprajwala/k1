<html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Charity System</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/owl-carousel/assets/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/animate.css">
	<link rel="stylesheet" href="assets/css/meanmenu.css">
	<link rel="stylesheet" href="assets/css/nivo-lightbox.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Lobster&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Acme&display=swap" rel="stylesheet">
	<style>
body {
  font-family: "Lato", sans-serif;
}
.bg {
  background-image: url("goods1.jpg");
  height: 100%; 
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}

.main {
	margin-left: 450px;
	margin-top:80px;
	margin-right:450px;	/* Same width as the sidebar + left position in px */
	/* Same width as the sidebar + left position in px */
  font-size: 25px; /* Increased text to enable scrolling */
  padding: 5px 20px 30px 20px;
}
.main font{
	font-family: 'Acme', sans-serif;
	opacity:1;
}
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
  table {
   border-collapse: collapse;
   width: 100%;
   color: #588c7e;
   font-family: monospace;
   font-size: 25px;
   text-align: left;
     } 
  th {
   background-color: #588c7e;
   color: white;
    }
  tr:nth-child(even) {background-color: #f2f2f2}
</style>
</head>
<body>
	<header>
	<nav  class="navigation">
			<div class="container">
				<div class="row">
					<div class="logo-wrap col-md-3 col-xs-6">
						<a href="index.php">Online Charity</a>
					</div>
					<div class="menu-wrap col-md-8 ">
						<ul class="menu">
								<li><a href="d_cash.php">Cash Donation</a></li>
								<li><a href="d_goods_donation.php">Goods Donation</a></li>
								<li><a href="d_ngosearch.php">NGO Search</a></li>
								<li><a href="d_profile.php">Profile</a></li>
								<li><a href="d_logout.php">Log Out</a></li>
					</div>
				</div>
			</div>
		</nav>
	</header>
	<?php
		$conn=mysqli_connect("localhost","root","","charity2") or die("could not find conn");
		$db=mysqli_select_db($conn,"charity2") or die("could not find db");
		$email=$_COOKIE["email"];
		setcookie("email",$email);
		$q="select d_name from donor_user where d_email='$email';";
		$arr=mysqli_query($conn,$q);
		$row=mysqli_fetch_array($arr,MYSQLI_BOTH); 
	?>
	<div class="bg">
	<br><br>
	<div class="main" style="background-color:white">
	<br><br>
		<form method="post" action="d_goods_donation_v.php"><center>
		<h2><font color="#CD5C5C"><u>SELECT MODE OF  DONATION..</u></font></h2><br>
		<h3>Goods You want to donate.... <input type="text" style="background:#D0D0D0" name="goods" required/><br><br>
		<h3>Goods quantity....<input type="text" style="background:#D0D0D0" name="quant" required/><br><br>
		<input type="radio" name="mode" value="mode1"/>  Donate to specific NGO<br><br>
		<input type="radio" name="mode" value="mode2"/>  Match the requirement<br><br></h3>
		<h3><input type="submit" name="submit" style="background:#CD5C5C; color:#ffffff; padding:5px 5px 5px 5px" value="Submit"/></h3>
		
	</form>
	<br></center><center>
	<table>
	<?php
		$conn=mysqli_connect("localhost","root","","charity2") or die("could not find conn");
		$db=mysqli_select_db($conn,"charity2") or die("could not find db");
		$mode=$_REQUEST["mode"];
		$goods=$_REQUEST["goods"];
		$quant=$_REQUEST["quant"];
		$email=$_COOKIE["email"];
		$id=$_COOKIE["id"];
		setcookie("id",$id);
		setcookie("email",$email);
		setcookie("goods",$goods);
		if($mode=="spec_ngo")
		{
			echo "<form method='post' action='d_goods_donation_v_spec.php'>
			<h3>NGO Name :  
			<select name='ngo_name' style='background:#D0D0D0'>
			<option value='Select NGO'>Select NGO</option>";
			$qu=mysqli_query($conn,'select * from ngo_login;');
			while($r=mysqli_fetch_array($qu,MYSQLI_BOTH))
			{
				$ngo=$r['name'];
				echo "<option value='$ngo' style='background:white'>$ngo</option>";
			}
			echo "<br>
			<h2><input type='submit' name='submit' style='background:#CD5C5C; color:#ffffff; padding:5px 5px 5px 5px' value='Submit'/>
			</form>
			";
		}
		else{
		$q="select * from ngo_req,ngo_login where ngo_login.id=ngo_req.ngo_id and ngo_req.req='$goods' and $quant<=ngo_req.quantity and priority=(select max(priority)from ngo_req,ngo_login where ngo_login.id=ngo_req.ngo_id and ngo_req.req='$goods' and $quant<=ngo_req.quantity);";
		$result = $conn->query($q);
			if ($result->num_rows > 0) {
				while($row = $result->fetch_assoc()) {
					echo "<tr><td>NGO NAME</td><td>".$row["name"]."</td></tr>".
						"<tr><td>NGO EMAIL</td><td>".$row["email"]."</td></tr>".
						"<tr><td>ADDRESS</td><td>".$row["address"]."</td></tr>".
						"<tr><td>PHONE NUMBER</td><td>".$row["phone_no"]."</td></tr>".
						"<tr><td>CITY</td><td>".$row["city"]."</td></tr>";
						setcookie("ngo",$row["name"]);
						echo "</table><br><form method='POST' action='d_goods_donation_v_match.php'>
						<input type='submit' name='donate' value='Donate' style='background:#CD5C5C; color:#ffffff; padding:5px 5px 5px 5px'/>
						</form>";
			}
			}
			else
			{
				echo "<center><tr><td>No NGO available with the requirement of $goods</td></tr></center>";
				$re=mysqli_query($conn,"select * from donor_items_left where d_email='$email' and items='$goods';");
				if(mysqli_num_rows($re)==0){
				mysqli_query($conn,"insert into donor_items_left values ('$email','$goods','$id','$quant');");
				}
			}
		}
	?>
	
	</center>
	</div>
	</div>
</body>
</html>