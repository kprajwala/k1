<?php
    session_start();
	$conn=mysqli_connect("localhost","root","","charity2") or die("could not find conn");
	?>
<html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Charity System</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/owl-carousel/assets/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/animate.css">
	<link rel="stylesheet" href="assets/css/meanmenu.css">
	<link rel="stylesheet" href="assets/css/nivo-lightbox.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Lobster&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Acme&display=swap" rel="stylesheet">
	<style>
	header .container{
			width:100%;
			padding:0px 40px 0px 40px;
		}
body {
  font-family: "Lato", sans-serif;
}
.bg {
  background-image: url("goods1.jpg");
  height: cover; 
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
.main {
  margin-left: 250px; /* Same width as the sidebar + left position in px */
  margin-right:250px;
  font-size: 28px; /* Increased text to enable scrolling */
  padding: 0px 5px;
}
.main font{
	font-family: 'Acme', sans-serif;
}
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
table {
   border-collapse: collapse;
   width: 100%;
   color: #588c7e;
   font-family: monospace;
   font-size: 25px;
   text-align: left;
     } 
  th {
   background-color: #588c7e;
   color: white;
    }
  tr:nth-child(even) {background-color: #f2f2f2}
  .details{
	  padding:70px 100px 100px 100px;
  }
</style>
</head>
<body>
	<header>
	<nav  class="navigation">
			<div class="container">
				<div class="row">
					<div class="logo-wrap col-md-3 col-xs-6">
						<a href="index.php">Online Charity</a>
					</div>
					<div class="menu-wrap col-md-8 ">
						<ul class="menu">
								
								<li><a href="recordsNGO.php">NGO Records</a></li>
								<li><a href="recordsDonor.php">Donor Records</a></li>
								<li><a href="sendMails.php">Send emails</a></li>
								<li><a href="feedback.php">Feedback</a></li>
								<li><a href="addNgo.php">Add Ngo</a></li>

								<li><a href="a_logout.php">LogOut</a></li>
						</ul>
					</div>
				</div>
			</div>
		</nav>
	</header><br><br>
	<div class="bg"><br><br><br><br>
	<div class="main">
	<div class="details" style="background:white">
	<h2><font color='#CD5C5C'><u><center>DONOR RECORDS</center></u></font></h2>
	
	<?php
		$q=mysqli_query($conn,"select * from donor_user;");
		while($row1=$q->fetch_assoc()){
			$email=$row1["d_email"];
			$sqlt = "SELECT ngo,items from donor_donations where d_email='$email';";
			$result = mysqli_query($conn,$sqlt);
			if (mysqli_num_rows($result) > 0) {
				echo "<h2><font color='#CD5C5C'><u>".$row1['d_name']."</u></font></h2><br>";
				echo "<table><th>NGO</th><th>Items</th><th>Cash</th>";
				while($row = $result->fetch_assoc()) {
					$n=$row["ngo"];
					$s=mysqli_query($conn,"select * from cash_records where d_email='$email' and ngo='$n'");
					if(mysqli_num_rows($s)==0){
						$casher=0;
					}
					else{
						$c=mysqli_fetch_array($s,MYSQLI_BOTH);
						$casher=$c["cash"];
					}
					echo "<tr><td>".$row["ngo"]."</td><td>".$row["items"]."</td><td>".$casher."</td></tr>";
			}
			$d=mysqli_query($conn,"select * from cash_records where d_email='$email'");
			while($row2 = $d->fetch_assoc()) {
				$ngo2=$row2["ngo"];
				if(mysqli_num_rows(mysqli_query($conn,"select * from donor_donations where ngo='$ngo2'"))==0){
					echo "<tr><td>".$ngo2."</td><td>--</td><td>".$row2["cash"]."</td></tr>";
				}
			}
			
			echo "</table><br><br>";
			}
			else{
				echo "<h2><font color='#CD5C5C'><u>".$row1['d_name']."</u></font></h2><br>";
				echo "<table><tr><td>No donation details</td></tr></table><br>";
			}
		}
		
	?>
	</div>
	</div>
	</div>
	</body>
	</html>