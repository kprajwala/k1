<html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Charity System</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/owl-carousel/assets/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/animate.css">
	<link rel="stylesheet" href="assets/css/meanmenu.css">
	<link rel="stylesheet" href="assets/css/nivo-lightbox.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Card Payment Forms Responsive Widget,Login form widgets, Sign up Web forms , Login signup Responsive web form,Flat Pricing table,Flat Drop downs,Registration Forms,News letter Forms,Elements" />
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
	function hideURLbar(){ window.scrollTo(0,1); } </script>
	
	<link href="style.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="creditly.css" type="text/css" media="all" />
	<link rel="stylesheet" href="font-awesome.css"> <!-- Font-Awesome-Icons-CSS -->
	<link href="//fonts.googleapis.com/css?family=Josefin+Sans:100,100i,300,300i,400,400i,600,600i,700,700i&amp;subset=latin-ext" rel="stylesheet">
	<style>
body {
  font-family: "Lato", sans-serif;
}
.bg {
  background-image: url("d_cash2.jpg");
  height: 91%; 
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
.main {
   margin-left: 100px; /* Same width as the sidebar + left position in px */
  font-size: 25px; /* Increased text to enable scrolling */
  padding: 0px 200px 0px 100px;
  margin-bottom:0px;
  height:79%;
}
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
.submit12{
	font-size: 25px;
	background: #FF4500;
	padding : 8px 8px 8px 8px;
}
</style>
</head>
<body>
	<header>
	<nav  class="navigation">
			<div class="container">
				<div class="row">
					<div class="logo-wrap col-md-3 col-xs-6">
						<a href="index.php">Online Charity</a>
					</div>
					<div class="menu-wrap col-md-8 ">
						<ul class="menu">
								<li><a href="d_cash.php">Cash Donation</a></li>
								<li><a href="d_goods_donation.php">Goods Donation</a></li>
								<li><a href="d_ngosearch.php">NGO Search</a></li>
								<li><a href="d_profile.php">Profile</a></li>
								<li><a href="d_logout.php">Log Out</a></li>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</nav>
	</header><br><br><br><br>
	<?php
		$conn=mysqli_connect("localhost","root","","charity2") or die("could not find conn");
		$db=mysqli_select_db($conn,"charity2") or die("could not find db");
		$email=$_COOKIE["email"];
		$id=$_COOKIE["id"];
		setcookie("id",$id);
		setcookie("email",$email);
		$q="select d_name from donor_user where d_email='$email';";
		$arr=mysqli_query($conn,$q);
		$row=mysqli_fetch_array($arr,MYSQLI_BOTH);
		 
	?>
	<div class="bg">
<br><br>
	<div class="main">
		<div id="myAccordion" class="nl-accordion">
		<ul>
			<li>
				<input type="radio" id="nl-radio-1" name="nl-radio" class="nl-radio" checked="checked"/>
				<label class="nl-label" style="background:#FF4500" for="nl-radio-1">Payment Card</label>
				<div class="nl-content">
					<div class="agileits_w3layouts_tab1 agileits_w3layouts_tab">
					<form action="d_cash_validate.php" method="post" class="creditly-card-form agileinfo_form">
						<section class="creditly-wrapper wthree w3_agileits_wrapper">
								<div class="first-row form-group">
								<div class="controls">
										<label class="control-label">NGO name..</label>
										<input class="billing-address-name form-control" type="text" name="ngo" placeholder="Name..." required="">									
								</div>
									<div class="controls">
										<label class="control-label">Name on Card</label>
										<input class="billing-address-name form-control" type="text" name="name" placeholder="Name..." required="">
									</div>
									<div class="controls">
										<label class="control-label">Card Number</label>
										<input class="number credit-card-number form-control" type="text" name="number"inputmode="numeric" autocomplete="cc-number" autocompletetype="cc-number" x-autocompletetype="cc-number" placeholder="&#149;&#149;&#149;&#149; &#149;&#149;&#149;&#149; &#149;&#149;&#149;&#149; &#149;&#149;&#149;&#149;" required="">
									</div>
									<div class="w3_agileits_card_number_grids">
										<div class="w3_agileits_card_number_grid_left">
											<div class="controls">
												<label class="control-label">Expiration Date</label>
												<input class="expiration-month-and-year form-control date" type="text" name="exp" placeholder="MM / YY" required="">
											</div>
										</div>
										<div class="w3_agileits_card_number_grid_right">
											<div class="controls">
												<label class="control-label">CVV</label>
												<input class="security-code form-control" Â·inputmode="numeric" type="password" name="security-code" placeholder="&#149;&#149;&#149;" required="">
											</div>
										</div>
										
									</div>
									<div class="controls">
										<label class="control-label">Amount..</label>
										<input class="billing-address-name form-control" type="text" name="amount" placeholder="Name..." required="">									
								</div>
								</div>
								<!--<button class="submit" type="submit"><span>Make a payment<i class="fa fa-long-arrow-right" aria-hidden="true"></i></span></button>-->
								<input type="submit" class="submit12" value="Make payment"/>
						</section>
					</form>
					</div>	
				</div>
			</li>
			
		</ul>
	</div>
	</div>
	</div>
<script type="text/javascript" src="jquery-2.1.4.min.js"></script>
<!-- //js -->
<!-- credit-card -->
	<script type="text/javascript" src="creditly.js"></script>
	<script type="text/javascript">
		$(function() {
		  var creditly = Creditly.initialize(
			  '.creditly-wrapper .expiration-month-and-year',
			  '.creditly-wrapper .credit-card-number',
			  '.creditly-wrapper .security-code',
			  '.creditly-wrapper .card-type');

		  $(".creditly-card-form .submit").click(function(e) {
			e.preventDefault();
			var output = creditly.validate();
			if (output) {
			  // Your validated credit card output
			  console.log(output);
			}
		  });
		});
	</script>	
</body>
</html>