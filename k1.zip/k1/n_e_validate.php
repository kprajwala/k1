<?php
	$conn=mysqli_connect("localhost","root","","charity2") or die("could not find conn");
	$sub=$_REQUEST["subAllNGO"];
	$msg=$_REQUEST["msgAllNGO"];
	$q=mysqli_query($conn,"select * from donor_user;");
	//echo "mails";
	while($r = $q->fetch_assoc()) {
		mail($r["d_email"],$sub,$msg,'From:onlinecharity2020@gmail.com');
	}
	header('Location: n_events.php');
?>