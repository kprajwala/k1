<html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Charity System</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/owl-carousel/assets/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/animate.css">
	<link rel="stylesheet" href="assets/css/meanmenu.css">
	<link rel="stylesheet" href="assets/css/nivo-lightbox.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Lobster&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Acme&display=swap" rel="stylesheet">
	<style>
body {
  font-family: "Lato", sans-serif;
}
.bg {
  background-image: url("goods1.jpg");
  height: 100%; 
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
.main {
 margin-left: 490px;
	margin-top:80px;
	margin-right:490px;	/* Same width as the sidebar + left position in px */
	/* Same width as the sidebar + left position in px */
  font-size: 25px; /* Increased text to enable scrolling */
  padding: 5px 50px 80px 50px;
  background-color:white;
}
.main font{
	font-family: 'Acme', sans-serif;
}
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

  table {
   border-collapse: collapse;
   width: 100%;
   color: #588c7e;
   font-family: monospace;
   font-size: 25px;
   text-align: left;
     } 
  th {
   background-color: #588c7e;
   color: white;
    }
  tr:nth-child(even) {background-color: #f2f2f2}
</style>
</head>
<body>
	<header>
	<nav  class="navigation">
			<div class="container">
				<div class="row">
					<div class="logo-wrap col-md-3 col-xs-6">
						<a href="index.php">Online Charity</a>
					</div>
					<div class="menu-wrap col-md-8 ">
						<ul class="menu">
								<li><a href="d_cash.php">Cash Donation</a></li>
								<li><a href="d_goods_donation.php">Goods Donation</a></li>
								<li><a href="d_ngosearch.php">NGO Search</a></li>
								<li><a href="d_profile.php">Profile</a></li>
								<li><a href="d_logout.php">Log Out</a></li>
						</ul>
					</div>
				</div>
			</div>
		</nav>
	</header><br><br><br><br>
	<?php
		$conn=mysqli_connect("localhost","root","","charity2") or die("could not find conn");
		$db=mysqli_select_db($conn,"charity2") or die("could not find db");
		$email=$_COOKIE["email"];
		setcookie("email",$email);
		$q="select d_name from donor_user where d_email='$email';";
		$arr=mysqli_query($conn,$q);
		$row=mysqli_fetch_array($arr,MYSQLI_BOTH);
		
	?>
	<div class="bg">
	<br><br><br>
	<div class="main">
	<br><br>
		<form method="post" action="d_goods_donation_v.php"><center>
		<h2><font color="#CD5C5C"><u>SELECT MODE OF  DONATION..</u></font></h2><br>
		<h3>Goods You want to donate..<input type="text" name="goods" required style="padding:6px 6px 6px 6px; text-color:#ffffff; background:#D0D0D0"/><br><br>
		<h3>Goods quantity....<input type="text" style="background:#D0D0D0" name="quant" required/><br><br>
		<input type="radio" name="mode" value="mode1"/>  Donate to specific NGO<br><br>
		<input type="radio" name="mode" value="mode2"/>  Match the requirement<br><br></h3>><br>
		<input type="submit" name="submit" value="Submit" style="background:#CD5C5C; color:#ffffff; padding: 5px 5px 5px 5px"/></h2>
		
	</form>
	
	
	<br><br></center><center>
	<table>
	<?php
		$conn=mysqli_connect("localhost","root","","charity2") or die("could not find conn");
		$db=mysqli_select_db($conn,"charity2") or die("could not find db");
		$email=$_COOKIE["email"];
		$goods=$_COOKIE["goods"];
		$ngo=$_COOKIE["ngo"];
		$id=$_COOKIE["id"];
		$qr="select * from donor_donations where d_email='$email' and ngo='$ngo';";
		$val=mysqli_query($conn,$qr);
		$row1=mysqli_fetch_array($val,MYSQLI_BOTH);
		if(mysqli_num_rows($val)==0)
		{
			$q="insert into donor_donations values ('$id','$goods','$ngo','$email');";
			mysqli_query($conn,$q);
			$qe="insert into d_donation_record values ('$id','$goods','$ngo','$email');";
			mysqli_query($conn,$qe);
			
		}
		else
		{
				$q3="select * from d_donation_record where d_email='$email' and ngo='$ngo'and items='$goods';";
				$arr3=mysqli_query($conn,$q3);
				if($arr3->num_rows ==0){
				$q2="select * from donor_donations where d_email='$email' and ngo='$ngo';";
				$arr2=mysqli_query($conn,$q2);
				$row2=mysqli_fetch_array($arr2,MYSQLI_BOTH);
				$i=$row2['items'];
				$items=$i.' , '.$goods;
				$q="update donor_donations set items='$items' where d_email='$email' and ngo='$ngo';";
				mysqli_query($conn,$q);
				$qs="insert into d_donation_record (donor_id,items,ngo,d_email) values ('$id','$goods','$ngo','$email');";
				mysqli_query($conn,$qs);}
		}
			$query=mysqli_query($conn,"select * from ngo_login where name='$ngo';");
			$r=mysqli_fetch_array($query,MYSQLI_BOTH);
			$ngo_id=$r['id'];
			$do=mysqli_query($conn,"select * from ngo_donations_record where ngo_id='$ngo_id' and donor_id='$id' and items='$goods';");
			if($do->num_rows==0)
			{
				mysqli_query($conn,"insert into ngo_donations_record(ngo_id,donor_id,items) values('$ngo_id','$id','$goods');");
				$q=mysqli_query($conn,"select * from ngo_donations where ngo_id='$ngo_id' and donor_id='$id';");
				if(mysqli_num_rows($q) != 0){
					$row=mysqli_fetch_array($q,MYSQLI_BOTH);
					$item_new=$row['items'];
					$items=$item_new.','.$goods;
					mysqli_query($conn,"update ngo_donations set items='$items' where ngo_id='$ngo_id' and donor_id='$id';");
				}
				else{
					mysqli_query($conn,"insert into ngo_donations(ngo_id,donor_id,items) values('$ngo_id','$id','$goods');");
				}
			}

		echo "Your details has been sent to the matched NGO ..$ngo....Thank You for donating";
		mail($email,'Confirmation of '.$goods.' Donation to '.$ngo,'ThankYou for donating '.$goods.' to '.$ngo.'....','From: onlinecharity2020@gmail.com');

		
	?>
	</center>
	</div>
	</div>
</body>
