<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname="charity2";	
    $conn = mysqli_connect($servername, $username, $password, $dbname)or die("could not find conn");
	$db=mysqli_select_db($conn,"charity2") or die("could not find db");
	session_start();
	if(isset($_POST["login"]))
	{
		$email=$_POST["email"];
		$pwd=$_POST["pwd"];
		$query=mysqli_query($conn,"SELECT * from ngo_login where email='$email';");
        $rows = mysqli_num_rows($query);
		if($rows==1)
		{
            $arr=mysqli_query($conn,"SELECT pwd,name from ngo_login where email='$email';");
            $row = mysqli_fetch_assoc($arr);
			if($pwd == $row['pwd'])
			{
				$arr1=mysqli_query($conn,"SELECT name from ngo_login where email='$email';");
                $row1 = mysqli_fetch_assoc($arr1);
                setcookie("username",$row1['name']);
                setcookie("email",$email);
				setcookie("id",$row1['id']);
				$id=$row1['id'];
				$_SESSION["value"]=$id;
                header('Location: ngo_landing.php');	
			}
			else
			{
                $_SESSION['pass']="true";
				if(isset($_SESSION['pass']))
                	header('Location: ngo_login.php');
			}
		}
		else
		{
			$_SESSION['no_user']="true";
			if(isset($_SESSION['no_user']))
            	header('Location: ngo_login.php');
           
		}
		
	}
?>