<?php
	$conn=mysqli_connect("localhost","root","","charity2") or die("could not find conn");
	$name=$_REQUEST["nameNGO"];
	$sub=$_REQUEST["subSpecNGO"];
	$msg=$_REQUEST["msgSpecNGO"];
	$q=mysqli_query($conn,"select * from ngo_login where name='$name';");
	$r=mysqli_fetch_array($q,MYSQLI_BOTH);
	mail($r["email"],$sub,$msg,'From:onlinecharity2020@gmail.com');
	header('Location: sendMails.php');
?>