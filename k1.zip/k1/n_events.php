<!DOCTYPE html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Charity System</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/owl-carousel/assets/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/animate.css">
	<link rel="stylesheet" href="assets/css/meanmenu.css">
	<link rel="stylesheet" href="assets/css/nivo-lightbox.css">
	<link rel="stylesheet" href="assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link rel="stylesheet" href="admin_login.css">
	<style>
		header .container{
			width:100%;
			padding:0px 40px 0px 40px;
		}
		.bg {
  background-image: url("ngo.jpg");
  height: 100%; 
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
	</style>
</head>
<body style="background:white">
	<header>
	<nav  class="navigation">
			<div class="container">
				<div class="row">
					<div class="logo-wrap col-md-3 col-xs-6">
						<a href="index.php">Online Charity</a>
					</div>
					<div class="menu-wrap col-md-8 ">
						<ul class="menu">
								<li><a href="n_goods_search.php">Search Items</a></li>
								<li><a href="n_goods_drecords.php">Goods Donation</a></li>
								<li><a href="n_events.php">Events</a></li>
								<li><a href="ngo_profile.php">Profile</a></li>
								<li><a href="ngo_logout.php">Log Out</a></li>
						</ul>
					</div>
				</div>
			</div>
		</nav>
	</header><br><br><br><br>
	
	<div class="bg">
	<br><br><br><br><br><br><br>
	<div class="container" style="background:white; padding:30px 0px 30px 0px;">
			<div class="row">
				<div class="col-md-10 col-md-offset-1">
					<div class="comment-form-wrapper contact-from clearfix">
						<div class="widget-title ">
							<h4>Notify About Events to All Donor's...</h4>	<br>
						</div>
						<form class="comment-form row altered" action="allNGO.php">
							
							<div class="field col-sm-4">
								<h4>Subject</h4>
								<input type="text" name="subAllNGO" required>
							</div>
							<div class="field col-sm-12">
								<h4>Message</h4>
								<textarea name="msgAllNGO" required></textarea>
							</div>
							<div class="field col-sm-4">
								<button class="btn btn-big btn-solid"><i class="fa fa-paper-plane"></i><span>Send Message</span></button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		</div>
		</body>
		</html>
		